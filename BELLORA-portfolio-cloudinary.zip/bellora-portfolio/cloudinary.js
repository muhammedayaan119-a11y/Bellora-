// BELLORA image uploads (Cloudinary free plan). Fill these values from your Cloudinary dashboard.
// Use an UNSIGNED upload preset restricted to image formats. Never put your API secret in browser code.
export const cloudinaryConfig = {
  cloudName: "YOUR_CLOUDINARY_CLOUD_NAME",
  uploadPreset: "YOUR_UNSIGNED_UPLOAD_PRESET"
};
export const cloudinaryConfigured = !Object.values(cloudinaryConfig).some(v => String(v).startsWith("YOUR_"));

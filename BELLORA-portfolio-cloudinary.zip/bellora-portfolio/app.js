import { db, firebaseConfigured } from "./firebase.js";
import { doc, getDoc, collection, getDocs, query, orderBy, where } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const defaults = {
  brandName:"BELLORA", heroEyebrow:"INDEPENDENT CREATIVE STUDIO",
  heroTitle:"Ideas made\nunforgettable.", heroText:"We shape thoughtful digital experiences and visual identities for ambitious people and brands.",
  aboutTitle:"Good design isn't decoration.\nIt's how things feel.", aboutText:"BELLORA is a creative practice for ideas that deserve clarity, character, and a little courage. We bring strategy and craft together to make work that feels considered, useful, and distinctly yours.",
  contactTitle:"Have a good one\nin mind?", contactEmail:"hello@bellora.studio", footerNote:"BELLORA © 2026 — MADE WITH INTENTION",
  theme:{accent:"#c7f36b",background:"#10100f",surface:"#1b1b19",text:"#f4f1e9"}
};
let allProjects = [];
const $ = id => document.getElementById(id);
function setText(id, value) { const el=$(id); if(el && value != null) el.textContent=value; }
function setHeadline(id, value) { const el=$(id); if(!el || value == null) return; const parts=String(value).split("\n"); el.replaceChildren(); parts.forEach((part,i)=>{if(i)el.append(document.createElement("br")); const last=i===parts.length-1; if(last){const em=document.createElement("em");em.textContent=part;el.append(em)}else el.append(document.createTextNode(part));}); }
function applyTheme(theme={}) { const t={...defaults.theme,...theme}; const r=document.documentElement; r.style.setProperty("--accent",t.accent);r.style.setProperty("--bg",t.background);r.style.setProperty("--surface",t.surface);r.style.setProperty("--text",t.text); }
function renderProjects(filter="All") {
 const grid=$("projectGrid"); const items=allProjects.filter(p=>filter==="All"||p.category===filter);
 grid.replaceChildren();
 if(!items.length){grid.innerHTML='<p class="muted empty-work">Projects will appear here soon. Check back for new work.</p>';return;}
 items.forEach((p,i)=>{
  const card=document.createElement("article");card.className="project-card reveal";card.style.setProperty("--delay",`${i*80}ms`);
  const visual=document.createElement("div");visual.className="project-visual";
  if(p.imageUrl){const img=document.createElement("img");img.src=p.imageUrl;img.alt=p.title||"Project cover";img.loading="lazy";visual.append(img)}
  else {const placeholder=document.createElement("div");placeholder.className=`project-placeholder tone-${i%4}`;placeholder.innerHTML=`<span class="placeholder-index">B / 0${i+1}</span><span class="placeholder-word">${escapeHtml((p.title||"BELLORA").split(" ")[0])}</span><span class="placeholder-shape"></span>`;visual.append(placeholder)}
  const meta=document.createElement("div");meta.className="project-meta";
  const copy=document.createElement("div");const title=document.createElement("h3");title.textContent=p.title||"Untitled project";const desc=document.createElement("p");desc.textContent=p.description||"Selected project";copy.append(title,desc);
  const cat=document.createElement("span");cat.className="project-category";cat.textContent=p.category||"Creative";meta.append(copy,cat);card.append(visual,meta);grid.append(card);
 });
 observeReveals();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function observeReveals(){const els=document.querySelectorAll(".reveal:not(.shown)");if(!("IntersectionObserver" in window)){els.forEach(e=>e.classList.add("shown"));return;}const obs=new IntersectionObserver(entries=>entries.forEach(en=>{if(en.isIntersecting){en.target.classList.add("shown");obs.unobserve(en.target)}}),{threshold:.12});els.forEach(e=>obs.observe(e));}
async function loadSite(){
 let data=defaults;
 if(firebaseConfigured){try{const snap=await getDoc(doc(db,"siteSettings","public"));if(snap.exists())data={...defaults,...snap.data(),theme:{...defaults.theme,...snap.data().theme}};const ps=await getDocs(query(collection(db,"projects"),where("published","==",true),orderBy("createdAt","desc")));allProjects=ps.docs.map(d=>({id:d.id,...d.data()})).filter(p=>p.published!==false);}catch(e){console.warn("Firebase content not available yet; using demo content.",e);}}
 if(!allProjects.length)allProjects=[
  {title:"Form & Function",category:"Branding",description:"A distinctive identity built around simplicity.",published:true},
  {title:"The New Ritual",category:"Digital",description:"A digital home for modern everyday living.",published:true},
  {title:"Soft Geometry",category:"Creative",description:"A playful study in shape, colour and balance.",published:true}
 ];
 setText("brandName",data.brandName);setText("heroEyebrow",data.heroEyebrow);setHeadline("heroTitle",data.heroTitle);setText("heroText",data.heroText);setHeadline("aboutTitle",data.aboutTitle);setText("aboutText",data.aboutText);setHeadline("contactTitle",data.contactTitle);setText("contactEmail",data.contactEmail);setText("footerNote",data.footerNote);
 const mail="mailto:"+encodeURIComponent(data.contactEmail||defaults.contactEmail);$("contactEmail").href=mail;$("contactLink").href=mail;applyTheme(data.theme);renderProjects();
}
$("filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProjects(b.dataset.filter);});
$("menuToggle").addEventListener("click",()=>document.getElementById("mainNav").classList.toggle("nav-open"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("nav-open")));
observeReveals();loadSite();
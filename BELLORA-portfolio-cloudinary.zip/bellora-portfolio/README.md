# BELLORA Portfolio — Firebase website

A responsive portfolio website with public pages, editable projects, image uploads, theme controls, and a protected admin workspace.

## Files
- `index.html` — public portfolio
- `login.html` — standard sign-in page
- `admin.html` — admin workspace
- `app.js`, `login.js`, `admin.js` — browser logic
- `firebase.js` — Firebase app setup (add your project config)
- `styles.css` — responsive design and animation
- `firestore.rules`, `storage.rules` — security rules

## 1. Create a Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. Add a **Web app** and copy its Firebase configuration.
3. Open `firebase.js` and replace all `YOUR_...` placeholder values.
4. In Firebase Console → Authentication → Sign-in method, enable **Email/Password**.
5. In Authentication → Users, add your admin user with an email and a strong password.
6. In Firestore Database, create a database.
7. In Storage, set up a Storage bucket.

## 2. Grant admin access securely
1. In Firebase Authentication → Users, copy the admin user's **UID**.
2. In Firestore, create a collection named `admins`.
3. Create a document whose document ID is exactly that UID.
4. Add field `active` with boolean value `true`.
5. Do not allow users to create or edit documents in `admins` from the website.

The admin link uses the same login form as normal users, but only an authenticated UID with an active `admins/{uid}` document is admitted. The app does not hardcode an admin email/password.

## 3. Apply security rules
Copy `firestore.rules` into Firestore → Rules and publish.
Copy `storage.rules` into Storage → Rules and publish.
If your Firebase project uses a custom Firestore database ID, adjust the Storage rule's Firestore reference accordingly. Firebase Storage rules may require enabling the documented Firestore integration/permissions in your project.

## 4. Run locally
Because this uses JavaScript modules, open it through a local web server, not by double-clicking the HTML file.
- Easiest: install Node.js and Firebase CLI, then run a static server such as `npx serve .`
- Or use VS Code with the Live Server extension.
- For deployment, use Firebase Hosting (recommended) or another HTTPS static host.

## 5. Deploy with Firebase Hosting
Install Firebase CLI, then from this folder:
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# Choose the current folder as public directory; configure as a single-page app: No
firebase deploy
```
If you select a different public folder during setup, place these files in that folder. Publish the rules separately in Firebase Console or via Firebase CLI.

## 6. Use the admin studio
Sign in at `login.html`, then use:
- Website content: edit copy and publish
- Projects: add/edit/delete project entries and upload a cover image
- Appearance: change accent, background, and text colours

Public portfolio content and projects are read from Firestore. If Firebase is not configured or content is not available, the public page shows demo content so the design can still be previewed.

## Security notes
- Never put a real password or service-account key in frontend code or commit it to a public repository.
- Firebase web config is intended to be present in browser code; database and Storage rules are what protect data.
- Keep admin creation manual or use a trusted server/Admin SDK. Do not expose an endpoint that lets a visitor grant themselves admin access.
- This is a static client-side site. For production, consider adding App Check, custom claims or a trusted server workflow for privileged administration.


## Image storage
This build uses Cloudinary for portfolio image uploads, not Firebase Storage. Follow `CLOUDINARY_SETUP.md` and fill in `cloudinary.js`. Firebase Storage Rules are not required.

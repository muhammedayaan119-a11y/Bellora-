# BELLORA: free image uploads without Firebase Storage

This version keeps Firebase Authentication and Firestore, but sends portfolio images to Cloudinary. Firebase Storage Rules are not needed.

## 1. Create Cloudinary settings
1. Create/sign in to a Cloudinary account and open the Console dashboard.
2. Copy the **Cloud name**.
3. Open **Settings → Upload** (Upload Presets). Create an upload preset and set **Signing Mode** to **Unsigned**.
4. Restrict the preset to image formats such as JPG, PNG, and WebP. Do not enable overwrite. Save the preset and copy its name.
5. Open `cloudinary.js` and replace `YOUR_CLOUDINARY_CLOUD_NAME` and `YOUR_UNSIGNED_UPLOAD_PRESET` with those values. Do not put your Cloudinary API secret in website code.

## 2. Configure Firebase
Open `firebase.js` and fill in the Firebase web app config. Keep Firestore rules restricted to your admin account; do not make all writes public. Firebase Authentication and Firestore still need to be configured.

## 3. Test
Host the site on HTTPS (or use a local development server), sign in as the admin, add a project and upload a small image. The project URL is saved in Firestore.

## Important security notes
- An unsigned preset name is visible in browser code. Anyone who discovers it may attempt uploads, so restrict allowed formats and transformations in the preset and monitor usage. Do not use this for sensitive/private images.
- The 5 MB limit in the form is a browser-side check; it is not a security boundary.
- Deleting a project removes its Firestore record but does not delete the Cloudinary image automatically.
- Cloudinary plan limits can change; check the current plan dashboard before publishing a production site.
